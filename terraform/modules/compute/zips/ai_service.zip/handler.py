import json
import os
import boto3
from datetime import datetime, timezone

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")

DOCUMENTS_TABLE = os.environ["DOCUMENTS_TABLE"]
JOBS_TABLE = os.environ["JOBS_TABLE"]
CONNECTIONS_TABLE = os.environ["CONNECTIONS_TABLE"]
DOCUMENTS_BUCKET = os.environ["DOCUMENTS_BUCKET"]
AWS_REGION_NAME = os.environ["AWS_REGION_NAME"]

documents_table = dynamodb.Table(DOCUMENTS_TABLE)
jobs_table = dynamodb.Table(JOBS_TABLE)
connections_table = dynamodb.Table(CONNECTIONS_TABLE)

BEDROCK_LLM_MODEL = "anthropic.claude-3-sonnet-20240229-v1:0"


def lambda_handler(event, context):
    # Handle direct Q&A API calls (from API Gateway)
    if "httpMethod" in event:
        return handle_qa_request(event)

    # Handle SQS trigger (post-OCR AI analysis)
    for record in event.get("Records", []):
        message = json.loads(record["body"])
        process_document(message)


# ── Document Processing Pipeline ──────────────────────────────────────────────

def process_document(message):
    user_id = message["user_id"]
    document_id = message["document_id"]
    text_key = message["text_key"]

    _update_job(document_id, "AI_IN_PROGRESS")

    try:
        # Load extracted text from S3
        obj = s3.get_object(Bucket=DOCUMENTS_BUCKET, Key=text_key)
        text = obj["Body"].read().decode("utf-8")

        # Generate summary and keywords via Bedrock
        summary = generate_summary(text)
        keywords = extract_keywords(text)

        # Update DynamoDB with AI results
        documents_table.update_item(
            Key={"user_id": user_id, "document_id": document_id},
            UpdateExpression="SET #s = :s, summary = :sum, keywords = :kw, updated_at = :u",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={
                ":s": "COMPLETE",
                ":sum": summary,
                ":kw": keywords,
                ":u": datetime.now(timezone.utc).isoformat(),
            },
        )

        _update_job(document_id, "COMPLETE")

        # Notify connected WebSocket clients
        notify_user(user_id, {
            "type": "PROCESSING_COMPLETE",
            "document_id": document_id,
            "summary": summary,
            "keywords": keywords,
        })

    except Exception as e:
        _update_job(document_id, "AI_FAILED", error=str(e))
        raise


# ── AI: Try Bedrock, fall back to local NLP ───────────────────────────────────

def generate_summary(text):
    """Try Bedrock Claude; fall back to extractive summary on failure."""
    try:
        return _invoke_claude(
            "You are a document analysis assistant. "
            "Provide a concise summary (3-5 sentences) of the following document:\n\n"
            f"{text[:8000]}"
        )
    except Exception:
        return _extractive_summary(text)


def extract_keywords(text):
    """Try Bedrock Claude; fall back to TF-IDF-style keyword extraction on failure."""
    try:
        response = _invoke_claude(
            "Extract 10 key topics or keywords from the following document. "
            "Return them as a JSON array of strings, e.g. [\"keyword1\", \"keyword2\"]. "
            "Return ONLY the JSON array, no other text.\n\n"
            f"{text[:4000]}"
        )
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            return [k.strip().strip('"') for k in response.strip("[]").split(",")]
    except Exception:
        return _frequency_keywords(text)


def _invoke_claude(prompt):
    bedrock = boto3.client("bedrock-runtime", region_name=AWS_REGION_NAME)
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": prompt}],
    })
    response = bedrock.invoke_model(modelId=BEDROCK_LLM_MODEL, body=body)
    result = json.loads(response["body"].read())
    return result["content"][0]["text"]


def _extractive_summary(text, num_sentences=5):
    """Return the first N meaningful sentences as an extractive summary."""
    import re
    sentences = re.split(r'(?<=[.!?])\s+', text.strip())
    # Filter out very short fragments
    sentences = [s.strip() for s in sentences if len(s.split()) > 5]
    return " ".join(sentences[:num_sentences]) if sentences else text[:500]


def _frequency_keywords(text, top_n=10):
    """Extract top N keywords by word frequency, ignoring common stop words."""
    import re
    from collections import Counter

    STOPWORDS = {
        "the","a","an","and","or","but","in","on","at","to","for","of","with",
        "is","are","was","were","be","been","being","have","has","had","do",
        "does","did","will","would","could","should","may","might","shall",
        "that","this","these","those","it","its","by","from","as","into",
        "not","no","so","if","then","than","when","where","which","who",
        "their","they","we","our","your","my","his","her","all","each",
        "any","both","few","more","most","other","some","such","up","out",
        "about","also","can","just","been","after","before","between",
    }
    words = re.findall(r'\b[a-zA-Z]{4,}\b', text.lower())
    filtered = [w for w in words if w not in STOPWORDS]
    common = Counter(filtered).most_common(top_n)
    return [word for word, _ in common]


# ── Q&A (RAG) ─────────────────────────────────────────────────────────────────

def handle_qa_request(event):
    user_id = event["requestContext"]["authorizer"]["claims"]["sub"]
    body = json.loads(event.get("body") or "{}")
    question = body.get("question")
    document_id = body.get("document_id")

    if not question:
        return _response(400, {"error": "question is required"})

    if not document_id:
        return _response(400, {"error": "document_id is required"})

    # Load document summary and text for context
    result = documents_table.get_item(
        Key={"user_id": user_id, "document_id": document_id}
    )
    item = result.get("Item")

    if not item:
        return _response(404, {"error": "Document not found"})

    if item.get("status") != "COMPLETE":
        return _response(400, {"error": "Document is still processing"})

    # Use summary + extracted text as context
    context = item.get("summary", "")
    text_key = item.get("s3_key", "") + ".extracted.txt"
    try:
        obj = s3.get_object(Bucket=DOCUMENTS_BUCKET, Key=text_key)
        full_text = obj["Body"].read().decode("utf-8")
        context = full_text[:12000]  # Use first 12k chars as context
    except Exception:
        context = item.get("summary", "No content available")

    prompt = (
        "You are a helpful document assistant. "
        "Answer the user's question using ONLY the context below. "
        "If the answer is not in the context, say 'I could not find this in the documents'.\n\n"
        f"Context:\n{context}\n\n"
        f"Question: {question}"
    )

    try:
        answer = _invoke_claude(prompt)
    except Exception:
        # Bedrock unavailable — do keyword-based search in the context
        answer = _keyword_answer(question, context)

    return _response(200, {
        "answer": answer,
        "sources": [{"document_id": document_id}],
    })


def _keyword_answer(question, context):
    """Simple fallback: find the sentence in context most relevant to the question."""
    import re
    q_words = set(re.findall(r'\b[a-zA-Z]{3,}\b', question.lower()))
    sentences = re.split(r'(?<=[.!?])\s+', context)
    scored = []
    for s in sentences:
        s_words = set(re.findall(r'\b[a-zA-Z]{3,}\b', s.lower()))
        score = len(q_words & s_words)
        if score > 0:
            scored.append((score, s.strip()))
    scored.sort(reverse=True)
    if scored:
        top = [s for _, s in scored[:3]]
        return "Based on the document: " + " ".join(top)
    return "I could not find a relevant answer in the document."


# ── WebSocket Notifications ────────────────────────────────────────────────────

def notify_user(user_id, payload):
    result = connections_table.query(
        IndexName="user_id-index",
        KeyConditionExpression=boto3.dynamodb.conditions.Key("user_id").eq(user_id),
    )

    if not result.get("Items"):
        return

    ws_endpoint = os.environ.get("WEBSOCKET_ENDPOINT", "")
    if not ws_endpoint:
        return

    apigw_mgmt = boto3.client(
        "apigatewaymanagementapi",
        endpoint_url=ws_endpoint,
    )

    message = json.dumps(payload)
    for conn in result["Items"]:
        try:
            apigw_mgmt.post_to_connection(
                ConnectionId=conn["connection_id"],
                Data=message.encode("utf-8"),
            )
        except Exception:
            connections_table.delete_item(
                Key={"connection_id": conn["connection_id"]}
            )


# ── Helpers ───────────────────────────────────────────────────────────────────

def _update_job(document_id, status, error=None):
    item = {
        "job_id": document_id,
        "status": status,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    if error:
        item["error"] = error
    jobs_table.put_item(Item=item)


def _response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body),
    }
